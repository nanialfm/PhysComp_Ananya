let sensorValue = 0;

function setup() {
  createCanvas(600, 600);
}

function draw() {

  let size = map(sensorValue, 0, 4095, 20, 200);
  let x = map(sensorValue, 0, 4095, 50, 550);
  let color = map(sensorValue, 0, 4095, 0, 255);

  background(color);

  fill(0, 0, 255);
  ellipse(x, 300, size, size);

  fill(255, 0, 0);
  rect(50, 50, size, 50);

  fill(0, 255, 0);
  triangle(300, 500, 250, 400, 350, 400);
}