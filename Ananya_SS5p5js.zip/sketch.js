let serial;
let state = 1;
let x = 200;

function setup() {
  createCanvas(800, 600);

  serial = createSerial();

  let connectButton = createButton("Connect");
  connectButton.mousePressed(connectSerial);
}

function draw() {
  background(30);

  x = x + 2;

  if (x > 800) {
    x = 0;
  }

  circle(x, 300, 80);
  rect(100, 400, 200, 50);
  line(100, 500, 700, 500);

  if (mouseIsPressed && mouseX < 400) {
    state = 1;
  }

  if (mouseIsPressed && mouseX > 400) {
    state = 2;
  }

  if (state == 1) {
    serial.println("1");
    text("LED ON", 350, 100);
  }

  if (state == 2) {
    serial.println("2");
    text("LED OFF", 350, 100);
  }
}

function connectSerial() {
  serial.open(9600);
}