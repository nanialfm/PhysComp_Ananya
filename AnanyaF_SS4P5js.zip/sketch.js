let potValue = 0;
let lightValue = 0;
let buttonValue = 0;
let touchValue = 0;

function setup() {
  createCanvas(600, 600);
}

function draw() {

  let circleSize = map(potValue, 0, 4095, 20, 200);
  let circleX = map(potValue, 0, 4095, 50, 550);

  let backgroundColor = map(lightValue, 0, 4095, 0, 255);

  let starSize = map(lightValue, 0, 4095, 10, 80);

  background(0, 0, backgroundColor);

  // Circle controlled by potentiometer
  fill(255, 0, 0);
  ellipse(circleX, 300, circleSize, circleSize);

  // Square
  fill(0, 255, 0);
  rect(50, 50, 100, 100);

  // Triangle
  fill(255, 255, 0);
  triangle(500, 100, 450, 200, 550, 200);

  // Line
  line(50, 500, 550, 500);

  // Button controls another circle
  if (buttonValue == 0) {
    fill(0, 0, 255);
    ellipse(300, 150, 50, 50);
  }

  // Touch controls the star
  if (touchValue == 1) {
    fill(255, 255, 255);
    ellipse(300, 450, starSize, starSize);
  }
}